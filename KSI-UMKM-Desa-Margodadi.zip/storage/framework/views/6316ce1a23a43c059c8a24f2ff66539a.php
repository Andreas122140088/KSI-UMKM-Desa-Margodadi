<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'UMKM Desa Margodadi'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('/css/homepage.css')); ?>">
    <link rel="icon" href="<?php echo e(asset('/img/logo.gif')); ?>">
</head>
<body>
    <div class="app-container">
        
        <?php echo $__env->yieldContent('navbar'); ?>

        
        <div class="content">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        
        <footer class="footer">
            <div class="footer-container">
                <div class="footer-links">
                    <h3>QUICK LINKS</h3>
                    <ul>
                        <li><a href="/home">Home</a></li>
                        <li><a href="/about">About</a></li>
                        <li><a href="/contact">Contact</a></li>
                        <li><a href="/product">Product</a></li>
                    </ul>
                </div>
                <div class="footer-service">
                    <h3>SERVICES</h3>
                    <ul>
                        <li><a href="#profile">Profile Desa</a></li>
                        <li><a href="#umkm">UMKM</a></li>
                    </ul>
                </div>

                <div class="footer-social">
                    <h4>CONTACT & FOLLOW US</h4>
                    <div class="social-icons">
                        <svg ...></svg><p>000000000000</p>
                        <svg ...></svg><p>Facebook.com</p>
                        <svg ...></svg><p>Instagram.com</p>
                        <svg ...></svg><p>Email.com</p>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; KSI-Kel 6 Copyright 2024 - All Right Reserved.</p>
            </div>
        </footer>
    </div>

    
    <script src="<?php echo e(asset('/js/app.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Project\KSI-UMKM-Desa-Margodadi\resources\views/layout/app.blade.php ENDPATH**/ ?>